import org.apache.spark.sql.functions._
import org.apache.spark.sql.SparkSession
import java.io.File

object task2_1 {
    def main(args: Array[String]) : Unit = {
        if (args.length != 2) {
            System.exit(1)
        }

        val input_path = args(0)
        val output_path = args(1)
        
        // Initialize Spark Session for local execution using all available CPU cores
        val spark = SparkSession
        .builder()
        .appName("Task2_1")
        .getOrCreate()

        spark.sparkContext.setLogLevel("OFF")
        val sc = spark.sparkContext

        import spark.implicits._

        try {
            // Load CSV with automatic type detection (Schema Inference)
            val df = spark.read
            .option("header", "true")
            .option("inferSchema", "true")
            .csv(input_path)

            // Filter for specific merchant-fulfilled, shipped orders to establish a baseline
            val state_avgs = df.filter(
                col("Fulfilment") === "Merchant" &&
                col("Courier Status") === "Shipped" && 
                col("Amount").isNotNull
            ).groupBy("ship-state").agg(avg("Amount").as("StateAvgAmount"))

            // Use the 'withColumn' transformation to process nested string data in 'promotion-ids'
            val filtered_orders = df.filter(
                col("ship-service-level") === "Standard" &&
                col("promotion-ids").isNotNull

            ).withColumn("ValidPromotionCount", {
                // Split string into array, filter out 'amazon' promotions, and count remaining elements
                val promotion_array = split(col("promotion-ids"), ",")
                size(filter(promotion_array, p => !lower(p).contains("amazon")))

            }).filter(col("ValidPromotionCount") >= 3)

            // Join local orders with state averages to find "below-average" spenders
            val joined_df = filtered_orders
            .join(state_avgs, "ship-state")
            .filter(col("Amount") < col("StateAvgAmount"))

            // Group by city to find the ratio of cancelled orders to total orders
            val results = joined_df
            .groupBy("ship-city")
            .agg(
                (count(when(col("Status") === "Cancelled", 1)) * 100.0 / count("*")).as("CancelledPercentage")
            )
            .orderBy(desc("CancelledPercentage"))

            results.write
            .mode("overwrite")
            .parquet(output_path)
            
        } finally {
            spark.stop()
        }
    }
}
